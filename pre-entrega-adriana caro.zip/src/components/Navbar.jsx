import '../components/navbar.css'
import CartWidget from './CartWidget'

const Navbar = () =>{
    return <nav className="header-nav">
    <a href="">Home</a>
    <a href="">Productos</a>
    <a href="">Productos</a>
    <a href="">Productos</a>
    <CartWidget/>
  </nav>
  }

  export default Navbar