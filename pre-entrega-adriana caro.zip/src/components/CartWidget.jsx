import reactLogo from '../assets/cart.svg'
import './cart.css'


export default function CartWidget() {
  return (
    <div>
      {<img src={reactLogo}/> }      <i data-count="3" className="fa fa-shopping-cart fa-5x fa-border icon-grey badge"></i>

    </div>
  )
}


