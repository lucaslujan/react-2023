
function Titulo(props){
    return(
        <h5>{props.titulo}</h5>
    )
}


const ItemListContainer = () =>{

    return (
        <div>
            <h1>ItemlistContainer</h1>
            <Titulo titulo='Pasando props'/>
        </div>
    )
}

export default ItemListContainer