
import './App.css'
import Navbar from './components/Navbar'
import ItemListContainer from './components/ItemListContainer'


const Footer=()=><footer>
<h3>Acá va el footer</h3>
</footer>


function App() {
  return (
      <div className=''>
        <Navbar/>
        <ItemListContainer/>
        <Footer/>
      </div>
  )
}

export default App
